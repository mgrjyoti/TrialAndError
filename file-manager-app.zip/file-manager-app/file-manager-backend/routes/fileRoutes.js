const express = require('express');
const multer = require('multer');
const { uploadFile, getFiles, deleteFile } = require('../controllers/fileController');
const authMiddleware = require('../middlewares/authMiddleware');

const upload = multer();

const router = express.Router();

router.post('/upload', authMiddleware, upload.single('file'), uploadFile);
router.get('/', authMiddleware, getFiles);
router.delete('/:id', authMiddleware, deleteFile);

module.exports = router;