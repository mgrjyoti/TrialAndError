const mongoose = require('mongoose');

const FileSchema = new mongoose.Schema({
    filename: String,
    url: String,
    userId: mongoose.Schema.Types.ObjectId
});

module.exports = mongoose.model('File', FileSchema);