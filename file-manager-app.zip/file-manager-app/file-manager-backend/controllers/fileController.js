const { Storage } = require('@google-cloud/storage');
const File = require('../models/fileModel');

const storage = new Storage();
const bucket = storage.bucket('your_bucket_name');

exports.uploadFile = async(req, res) => {
    const { originalname, buffer } = req.file;
    const blob = bucket.file(originalname);
    const blobStream = blob.createWriteStream({
        resumable: false,
    });

    blobStream.on('error', err => {
        res.status(500).send(err.message);
    });

    blobStream.on('finish', async() => {
        const url = `https://storage.googleapis.com/${bucket.name}/${blob.name}`;
        const file = new File({ filename: originalname, url, userId: req.user.userId });
        await file.save();
        res.status(200).json({ url });
    });

    blobStream.end(buffer);
};

exports.getFiles = async(req, res) => {
    const { page = 1, search = '' } = req.query;
    const limit = 10;
    const files = await File.find({ filename: { $regex: search, $options: 'i' }, userId: req.user.userId })
        .skip((page - 1) * limit)
        .limit(limit);
    const totalFiles = await File.countDocuments({ filename: { $regex: search, $options: 'i' }, userId: req.user.userId });
    res.json({ files, totalPages: Math.ceil(totalFiles / limit) });
};

exports.deleteFile = async(req, res) => {
    const { id } = req.params;
    const file = await File.findByIdAndDelete(id);
    if (file) {
        const blob = bucket.file(file.filename);
        await blob.delete();
        res.status(200).send('File deleted');
    } else {
        res.status(404).send('File not found');
    }
};